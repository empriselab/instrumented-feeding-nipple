rosrun rqt_plot rqt_plot \
/wireless_ft/raw_sensor_counts/axes[18] \
/wireless_ft/raw_sensor_counts/axes[19] \
/wireless_ft/raw_sensor_counts/axes[20] \
/wireless_ft/raw_sensor_counts/axes[21] \
/wireless_ft/raw_sensor_counts/axes[22] \
/wireless_ft/raw_sensor_counts/axes[23] \
