rosrun rqt_plot rqt_plot \
/wireless_ft/raw_sensor_counts/axes[24] \
/wireless_ft/raw_sensor_counts/axes[25] \
/wireless_ft/raw_sensor_counts/axes[26] \
/wireless_ft/raw_sensor_counts/axes[27] \
/wireless_ft/raw_sensor_counts/axes[28] \
/wireless_ft/raw_sensor_counts/axes[29] \
