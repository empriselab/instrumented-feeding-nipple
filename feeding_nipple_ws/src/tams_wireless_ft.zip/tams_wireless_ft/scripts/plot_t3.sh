rosrun rqt_plot rqt_plot \
/wireless_ft/raw_sensor_counts/axes[12] \
/wireless_ft/raw_sensor_counts/axes[13] \
/wireless_ft/raw_sensor_counts/axes[14] \
/wireless_ft/raw_sensor_counts/axes[15] \
/wireless_ft/raw_sensor_counts/axes[16] \
/wireless_ft/raw_sensor_counts/axes[17] \
