rosrun rqt_plot rqt_plot \
/wireless_ft/raw_sensor_counts/axes[0] \
/wireless_ft/raw_sensor_counts/axes[1] \
/wireless_ft/raw_sensor_counts/axes[2] \
/wireless_ft/raw_sensor_counts/axes[3] \
/wireless_ft/raw_sensor_counts/axes[4] \
/wireless_ft/raw_sensor_counts/axes[5] \
