rosrun rqt_plot rqt_plot \
/wireless_ft/raw_sensor_counts/axes[6] \
/wireless_ft/raw_sensor_counts/axes[7] \
/wireless_ft/raw_sensor_counts/axes[8] \
/wireless_ft/raw_sensor_counts/axes[9] \
/wireless_ft/raw_sensor_counts/axes[10] \
/wireless_ft/raw_sensor_counts/axes[11] \
